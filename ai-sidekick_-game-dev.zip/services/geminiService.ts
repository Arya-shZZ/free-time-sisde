import { GoogleGenAI } from "@google/genai";
import { GameDevLevel } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getSystemInstruction = (level: GameDevLevel): string => {
    if (level === GameDevLevel.Architecture) {
        return `You are a world-class senior game architect. 
Your task is to design robust, scalable, and well-documented systems for game concepts.
Provide a high-level architectural plan. This should include:
1.  **Core Concepts**: A brief overview of the system's purpose.
2.  **Data Structures**: Define necessary C# classes, structs, or JSON-like object structures.
3.  **Key Components & Logic**: Describe the main classes or modules and their responsibilities. Outline key functions/methods with signatures.
4.  **Relationships**: Explain how different parts of the system interact.
Do NOT write full implementation code. Focus on creating a clear, professional blueprint.`;
    }
    // Default to Snippet
    return `You are a hyper-focused game development assistant. 
Your task is to provide concise, clean, and correct code snippets for specific game mechanics.
- Provide ONLY the code snippet requested.
- Do not add any extra explanations, introductions, or summaries unless the code is highly complex.
- The code should be production-quality and easy to understand.
- Assume the user is an experienced developer who can integrate it.`;
};

export const generateGameDevContent = async (prompt: string, level: GameDevLevel): Promise<string> => {
    const systemInstruction = getSystemInstruction(level);
    const model = 'gemini-2.5-flash-preview-04-17';

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: level === GameDevLevel.Snippet ? 0.3 : 0.7,
                topP: 0.95,
                topK: 64,
            }
        });

        return response.text;
    } catch (error) {
        console.error("Error generating content from Gemini:", error);
        if (error instanceof Error) {
            return `Error from AI service: ${error.message}`;
        }
        return "An unknown error occurred while contacting the AI service.";
    }
};
