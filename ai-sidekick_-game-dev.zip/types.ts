export enum GameDevLevel {
  Snippet = 1,
  Architecture = 2,
}
